# ICS2O-☺The Game Changers☺-LR-AP
Learn with us game summative - Lior Rozin and Akash Prasad;

Image album: https://imgur.com/a/NEVNEtQ

Link to our game: https://bit.ly/2KnPjab
